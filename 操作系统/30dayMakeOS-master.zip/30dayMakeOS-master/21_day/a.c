void api_putchar(int c);
void api_end(void);

void HariMain(void)
{
	api_putchar('A');
	api_end();
}
